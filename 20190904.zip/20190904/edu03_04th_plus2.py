def functest():
	print("Function Test")

if __name__=="__main__":
	functest()
