
'''
def num_alp(key):
	listcode=[(chr(x+65),x) for x in range(26)]
	dictcode={}
	for x in listcode:
		head,tail=x[0],(x[1]+1)**3
		dictcode[head]=tail
	print(listcode,'\n')
	print(dictcode,'\n')

	if key in dictcode:
		words=dictcode[key]
	else:
		return None
	return words

keydat=num_alp('B')
print("Result is : ",keydat)
'''
'''
mylist=[]
modify_list()
print(*mylist)
'''
print((lambda x : x**2)(3))

mylist2=[x for x in range(1,10)]
print(mylist2)
#(문제)1,3,5,7,9만 나오게 코드를 수정하시오
mylist3=[x for x in range(1,10,2)]
print(mylist3)