#set (class)
myset={3,1,5,8,9,3,1,5,8,9}
#중복을 허용하지 않음 + 자동 sort
print(myset)
print(type(myset))
print()
print("Set type Calc.") #비트단위 연산과 닮았음...?
print()
setdat1={1,3,5,7}
setdat2={2,3,6,7}
res=setdat1|setdat2
print("합집합",res) 
res=setdat1&setdat2
print("교집합",res)
res=setdat1-setdat2
print("차집합",res)
res=setdat1^setdat2
print("교집합의 여집합",res)
print()
print("Set에 항목 추가") 
print()
print("1. add method")
print()
print(myset)
myset.add(12)
print("=>")
print(myset)
myset.add(9)
print(myset)
print()
print("2. union method")
print()
print("initial data is : ",myset)
myset2=myset.union([13,15,19])
print(myset2)
print()
print("Set에 항목 제거") 
print()
print("1. remove method")
print()
print("initial data is : ",myset)
myset.remove(5)
print(myset)
#myset.remove(22)
#print(myset)print()
print("2. discard method")
print()
print("initial data is : ",myset)
myset.discard(1)
print(myset)
myset.discard(33)
print(myset)
#list -> set -> list
mylist=[3,1,6,5,22,3,8,6,11]
print("initial list is : ",mylist)
stset=set(mylist)
print("TFd set is : ",stset)
stset_add=stset.union([39,19,29])
print(stset_add)
mod_list=list(stset_add)
print("Modded list is : ",mod_list)
st_list=sorted(mod_list)
print("Sorted list is : ",st_list)
print()
#공통문자출력
spstr1="python is simple"
spstr2="apple is sweet"
spstr3="programming"

spset1=set(spstr1)
spset2=set(spstr2)
spset3=set(spstr3)

res=spset1&spset2&spset3
print(res)