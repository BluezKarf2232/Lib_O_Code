from mysmart1 import mycamera
from mysmart1 import myphone
from mysmart1 import myaddress
