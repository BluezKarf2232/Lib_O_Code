def displaylist():
	print("address display..")

if __name__=='__main__':
	displaylist()