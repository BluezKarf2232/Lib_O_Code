def makecall():
	print("Make a Call")

if __name__ == "__main__":
	makecall()