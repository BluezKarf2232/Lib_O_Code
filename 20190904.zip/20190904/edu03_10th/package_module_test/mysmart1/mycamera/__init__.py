from mysmart1.mycamera import camera
