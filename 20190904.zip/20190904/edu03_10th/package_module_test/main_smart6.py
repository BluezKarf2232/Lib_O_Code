import mysmart1 #디렉토리 불러오기. 각 폴더에 __init__.py 있는지 다시 확인해 보구.

def smart_on():
	while True:
		choice = input("what do you want ? :")
		if choice == '0':
			break
		if choice == "1":
			mysmart1.mycamera.camera.photo()
			'''
			mysmart1 폴더 아래 mycamera 폴더 아래 
			camera 파일(모듈) 아래 photo 함수 호출
			단, 그 폴더에 '__init__.py'가 있어야만 함
			'''
		elif choice == "2":
			mysmart1.myphone.phone_mod.makecall()
			'''
			mysmart1 폴더 아래 myphone 폴더 아래 
			phone_mod 파일(모듈) 아래 makecall 함수 호출
			단, 그 폴더에 '__init__.py'가 있어야만 함
			'''
		elif choice == "3":
			mysmart1.myaddress.addresslist.displaylist()
			'''
			mysmart1 폴더 아래 myaddress 폴더 아래 
			addresslist 파일(모듈) 아래 displaylist 함수 호출
			단, 그 폴더에 '__init__.py'가 있어야만 함
			'''
		else:
			print("다시 입력해 주세요")
	print("프로그램 종료")

if __name__ == "__main__":
	smart_on()
