#반복문의 응용
#1
total=0
for x in range(1,10):
	if x%2==0:
		continue
	total+=x
print(total)
print("========")
prtlist=[]
for ch in "python":
	if ch=='y':
		print("{}".format(ch))
		prtlist+=ch
	else:
		print("{}".format(chr(ord(ch)-32)))
		prtlist+=chr(ord(ch)-32)
print("".join(prtlist))
print("========")
spdic={'a':1,'b':2,'c':3,'d':4}
for key in spdic:
	print("{","{} : {}".format(key,spdic[key]),"}")
print("========")
print("자라나라")
count=10
while count:
	print("머리머리")
	count-=1