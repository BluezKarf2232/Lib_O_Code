#Functions

def smplfunc(det1,det2):
	print("First data is : %d, Second data is : %d" %(det1,det2))

num=2
smplfunc(num,3)
print("===========================")
#Varient index usage
def BeTuple(*det):
	i=0
	for x in det:
		i+=1
	print("내부 데이터 개수 : %d"%i)
	print(det)
	for x in range(0,len(det)):
		print(det[x])


def BeDict(**det):
	i=0
	for x in det.keys():
		i+=1
	print("내부 데이터 개수 : %d"%i)
	print(det)

BeTuple(1,[2,3],{'A':4,'B':5,'C':6})
BeDict(A=1,B=2,C=3)
print("===========================")
def func1(det):
	for num in det:
		print(num)

def func2(det):
	for num in det:
		print(num,det[num])

def func3(det):
	for num, value in det:
		print(num,value)

test1=(1,2,3,4,5)
test2={"A":1,"B":2,"C":3}
test3=[(1,2),(4,8),(16,32)]
func1(test1) 
print()
func2(test2) 
print()
func3(test3) 
print()
print("===========================")
mylistdata=[1,23,56,77,99]
print(mylistdata)
print(*mylistdata) #print함수의 기능 : 틀 없이 값만 출력
print(*mylistdata, sep='\n') #sep : 값 사이를 분할할 때 넣을 문자 적용
print("===========================")
def mutifl(bas,*count):
	cnt=0
	lenth=len(count)
	while cnt<lenth:
		print("{}".format(bas*count[cnt]))
		cnt+=1

def upchange(words):
	rst=words.upper()
	print(rst)

res=mutifl(9,1,2,4,6,8)
print()
upchange("python")