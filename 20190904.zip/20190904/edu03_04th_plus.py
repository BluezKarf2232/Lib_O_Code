import edu03_04th

edu03_04th.circle_cal()