
def functest1():
	gdata="This is Local data!"
	gval=7
	print("Function test, Inner value : ", locals())

gdata="This is Global data!"
functest1()
print(gdata)
print("Function test, Outer value : ", locals())
#local() : 해당 '공간'의 데이터들을 dict 타입으로 출력

def functest2():
	global gdata #전역공간의 변수 끌어오기. 안 하고 그냥 쓰면 에러남
	gdata+=5
	print("Local value : ", gdata)

gdata=3
print("Original gdata : ",gdata)
functest2()
print("gdata now : ",gdata)

def modify_list():
	mylist.append(30)
	mylist.append(40)
	mylist.append(50)
	mylist.append([x for x in range(60,120,10)])

mylist=[]
modify_list()
print(*mylist)

print((lambda x : x**2)(3))

mylist=[lambda x : x**3, lambda x : x+11]
print(mylist)
res=mylist[1](5)
print(res)