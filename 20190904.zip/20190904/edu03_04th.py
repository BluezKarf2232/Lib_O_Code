def circle_cal():
	while True:
		prs=input("반지름 입력(cm 단위로) : ")
		if prs=="end":
			break
		else:
			rad=float(prs)
			print("입력한 반지름 값은 : ",rad,'cm,')
			circle_area=rad*rad*3.14
			circle_len=2*3.14*rad
			print("원의 면적은 : {0:0.2f}".format(circle_area),'cm^2')
			print("원의 둘레 길이는 : {0:0.2f}".format(circle_len),'cm')
'''
if __name__=="__main__":
	circle_cal()
'''
#아래 문자열 데이터에서 영문자만 추출하기.
smpstr="#s45cD!K2ab@"
catlist=[]
for x in smpstr:
	if x>='a' and x<='z':
		catlist.append(x)
	elif x>='A' and x<='Z':
		catlist.append(x)
print(catlist)
res_cat=" ".join(sorted(catlist))
print(res_cat)
print("++++++++++")
#1~100의 숫자 중 2와 3의 공배수이면서 4의 배수가 아닌 수의 리스트.
listdat=[x for x in range(1,101) if ((x%2==0 and x%3==0) and (x%4!=0))]
print(listdat)