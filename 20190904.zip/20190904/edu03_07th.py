#함수응용
a=10
b=20
def swapper():
	global a,b
	a,b=b,a
print("Original a : %d, b : %d"%(a,b))
swapper()
print("Changed a : %d, b : %d"%(a,b))

def masher(code):
	for x in code:
		if x in code_book:
			code=code.replace(x,code_book[x])
	return code
'''
def cooker(code):
	for x in code:
		if x in code_book.values():
			code=code.replace(x,code_book.keys[x])
'''
code_book={'a':'@','e':'2','i':'!','o':'0','u':'^'}
print('=================')
tstcode="I love chocolate banana sandwich"
print("Original code is : ",tstcode)
code_mash=masher(tstcode)
print(code_mash)

def de_codin(code):
	de_coder={}
	for x in code:
		de_coder[code[x]]=x
	return de_coder

def de_masher(code):
	for x in code:
		if x in res:
			code=code.replace(x,res[x])
	return code

res=de_codin(code_book)
print(res)
rst=de_masher(code_mash)
print(rst)