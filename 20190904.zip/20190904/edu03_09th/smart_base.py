#smart_base.py
import camera as cam
import phone_base as phn

def smart_on(): 
	print("="*20)
	'''
	camera.photo()
	phone_base.make_call()
	'''
	while True:
		choice=input("What do you want? : ")
		if choice=='0':
			break
		if choice=='1':
			cam.photo()
		elif choice=='2':
			phn.make_call()
		elif choice=='3':
			print("미구현 기능입니다")
		else:
			print("다시 입력해 주십시오")
	print("프로그램이 종료되었습니다")
if __name__=="__main__":
	smart_on()