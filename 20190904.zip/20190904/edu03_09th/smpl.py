x=90
def sptest():
	print('x from sample is : ',x)