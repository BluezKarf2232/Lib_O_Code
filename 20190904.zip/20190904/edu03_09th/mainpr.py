#1 정석
import sptest
x=999
def mntest():
	print('x from main is : ',x)

smpl.sptest()
mntest()
'''
#2 모듈 째로 불러오기
from smpl import sptest
x=999
def mntest():
	print('x from main is : ',x)

smpl.sptest()
mntest()
'''
#3 불러온 모듈에 별명 붙이기...는 smart-base.py 파일 봐라