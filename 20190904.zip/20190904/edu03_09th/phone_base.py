#phone_base.py

def make_call():
	print("Make a Call")

if __name__=="__main__":
	make_call()
	print("phone_base.py`s module name is : ",__name__)