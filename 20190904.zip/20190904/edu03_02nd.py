a=True
print("참트루") if a==True else print("안트루")
print()

tst2=[x for x in range(0,10)]
print(tst2)
'''
tst=[]
for x in range(0,10):
	tst+=[x]
print(tst)
...와 같은 기능을 함.
'''
print()
even_odd=["Even!" if x%2==0 else "Odd..." for x in range(1,11)]
print(even_odd)
print()
tstno10=["A" if x%3==1 else "B" if x%3==2 else "C" for x in range(1,20)]
print(tstno10)
countA=0
countB=0
countC=0
for x in range(0,len(tstno10)):
	if tstno10[x]=='A':
		countA+=1
	elif tstno10[x]=='B':
		countB+=1
	else:
		countC+=1
print(countA,countB,countC)
print(countA+countB+countC)
print()
mydatalist=[(3,4,5,8),(5,6,5,5,7),(7,8,1)]
for x in mydatalist:
	for y in x:
		print(y,end=' ')
	print()
print()
