class myclasstest():
	var=78 #class 속성 변수
	def __init__(self,data): #
		print("__init__ function...")
		var=20 #__init__내부 지역변수
		self.var=data #instance 속성 변수
myinstance1=myclasstest(30) 
#myclasstest 클래스를 이용해 하나의 인스턴스 객체를 생성
#이때, 자동으로 호출되는 __init__()함수에 인수를 전달하여 수행

print("instant1 : ",myinstance1.var)
print(myclasstest.var)
myinstance2=myclasstest(50)
print("instant2 : ",myinstance2.var)
print(myclasstest.var)