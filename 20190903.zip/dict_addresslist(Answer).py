
def InsertData():
	name = input("이름 입력 : ")
	phone = input("전번 입력 : ")
	addresslist[name] = phone

def DisplayData(address_arg):
	for key in address_arg:
		print(key, " : ", address_arg[key])

def DeleteData(address_arg):
	delname = input("삭제할 이름 입력 : ")
	if delname in address_arg:
		del address_arg[delname]

def MenuSel():
	mytuple = ( "1.Insert" , "2.Diplay" , "3.Delete" , "4.Exit" )
	for x in mytuple:
		print(x,"  ",end="")
	else:
		print("\n")

	sel = int(input("meun sel : "))
	return sel

def runprogram():
	while True:
		selnum = MenuSel()
		if selnum == 1:
			InsertData()
		elif selnum == 2:
			DisplayData(addresslist)
		elif selnum == 3:
			DeleteData(addresslist)
		elif selnum == 4:
			break

if __name__ == "__main__":
	addresslist = {}		
	runprogram()