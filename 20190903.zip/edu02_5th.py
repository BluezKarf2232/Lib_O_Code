#데이터 정렬하기
print("1. 메소드로 정렬")
rawdata=[3,8,1,4,6]
print(rawdata)
rawdata.sort()#오름차순 정렬(작은 수-큰 수)
print(rawdata)
rawdata.reverse()#내림차순 정렬(큰 수-작은 수)
print(rawdata)
print()
print("2. 내장함수로 정렬")
rawdata=[3,8,1,4,6]
sortdata=sorted(rawdata)
print(rawdata)
print(sortdata)
print()
print("sp. Join method 활용")
example=["Put","a","Comment","Here"]
res="".join(example)
print(res)
print()

