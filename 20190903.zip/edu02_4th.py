#List의 복사
import copy #이거 없음 copy 작동 안함

def shallow_copy():
	print("#1. shallow copy(ID를 복사)")
	rawlist=[[10,20,30],40,50]
	scopy=copy.copy(rawlist)
	print(rawlist)
	print(id(rawlist[0]))
	rawlist[0].append(99)
	print("Raw data reads : ",rawlist)
	print("Copied data reads : ",scopy)
	print(id(scopy[0]))


def deep_copy():
	print("#2. Deep copy(값을 복사)")
	rawlist=[[10,20,30],40,50]
	print("rawlist ID is : ",id(rawlist))
	dcopy=copy.deepcopy(rawlist)
	print(rawlist)
	print("Deep copied ID is : ",id(dcopy))
	print("rawlist[0] id is :",id(rawlist[0]))
	rawlist[0].append(99)
	print("rawlist : ",rawlist)
	print("Deep copy : ",dcopy)
	print("Deep copied ID is : ",id(dcopy))


shallow_copy()
print()
deep_copy()