#문자열 컨트롤
sample="progRamMin riBbit"
print("capitalize shift first letter into upper letter and others into lower letters")
print(sample.capitalize())
print("center fits the words to center")
print(sample.center(50,'@')) #...잘 안 씀
#center((총 문자 개수),(나머지를 채울 문자))
print("count do count the number of target word's'")
print(sample.count('i'))
print("")
holo='/'.join(sample)#각 문자열 사이에 / 를 끼워넣음. 그 대상은 순차적이어야만 함
print(holo)
yolo=holo.split('/')#/ 를 기준으로 문자들을 쪼갬
print(yolo) #이 값은 list로 나옴

for x in range(0,len(sample)):
	if ord(sample[x])==ord(sample[x].casefold()):
		print(sample[x], ', It`s lower letter')
	else:
		print(sample[x], ', It`s upper letter')

print(sample)
print(type(sample))
sampie=sample.replace('i','"Bwah!"') #replace!
print(sampie)
print(type(sampie))

pin_num="990415-1234567"
yymmdd=pin_num[:6]
num_id=pin_num[7:]
print(yymmdd)
print(num_id)
if pin_num[7]==1:
	print("Male")
else:
	print("Female")