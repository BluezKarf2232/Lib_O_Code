#string 과 list
spstr="ProgrAmming"
splst=list(spstr)

#공통점

print("색인연산이 가능하다")
print(spstr[2])
print(splst[2])
print("합연산, 곱연산 모두 가능하다")
print(spstr+spstr)
print(splst+splst)
print(spstr*4)
print(splst*4)
print("분할연산도 가능하다")
print(spstr[5:])
print(splst[5:])
print(spstr[:8])
print(splst[:8])
print(spstr[::-1])
print(splst[::-1])
print("문자열, list간 전환")
print(list(spstr)) #문자열을 list로
print("".join(splst)) #list를 문자열로

#차이점
print("1. list안에 넣는 객체 타입에 제약이 없다!")
ttlist=[3.14,5,"python",[100,200,300],["Good","Programming"]]
print(ttlist[0])
print(ttlist[1])
print(ttlist[2][0])
print(ttlist[3][1])
print(ttlist[4][1])
print(ttlist[4][0][3])
'''
ttinput1=float(input("정수 하나 입력 : "))
ttinput2=float(input("정수  또 하나 입력 : "))
#input함수 = 키보드 입력을 받는다. 기본입력은 str
res=ttinput1+ttinput2
print("Result is : ",res)
print(type(res))
'''
print("2. 내부 객체를 수정 가능하다") #=mutable 한 객체다.
listdata=[]
for x in range(0,5):
	addata=int(input("정수 하나 입력 : "))
	print(addata)
	listdata.append(addata)
print(listdata)
'''
sum=0
for x in range(0,len(listdata)):
	print(listdata[x])
	sum=sum+listdata[x]
print(sum) #내가 만든거
'''
total=0
for x in listdata:
	print("Data is : ",x)
	total+=x
print("Total is : ",total) #모범답안