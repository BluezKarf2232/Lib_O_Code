#dict type
mydict={}
print(type(mydict))
'''
입력법:
dict[(immutable value)]=(Value)
'''
mydict["Korean"]=100
mydict["Math"]=70
mydict["English"]=80

print(mydict)
print(mydict["Math"])
mydict["Math"]=90 
#수정방법: dict[(Key)]=(Changing Value)
print(mydict["Math"])
#의외로, list는 dict와 같은 방법으로는 내용을 추가할 수 없다.

a=77
b=[1,2,3]
c="Python"
tdict={a:b,tuple(b):c,c:a}
print(tdict)
print()
##################
print("Delete data in dic")
prey={'A':90,'B':80,'C':70}
print(prey)
hang=prey.pop('B')
print(prey)
print(hang)
print()
prey={'A':90,'B':80,'C':70}
print(prey)
del prey['C']
print(prey)
print()
print('Mod de dict')
prey={'A':90,'B':80,'C':70}
print(prey)
prey['A']=180
print(prey)
prey['D']=30
print(prey)
print()
print("Upddate method") 
#아래 조건문이 돌아갈 때 + 조건문 없을 때 어떻게 돌아가는지 잘 볼 것
prey={'A':90,'B':80,'C':70}
mod_dat={'B':"Bbaa",'D':"Baam"}
for key in mod_dat:
	#if key not in prey:
	#if key in prey:
		prey.update({key:mod_dat[key]})
print(prey)