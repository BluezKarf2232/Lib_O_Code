#전화번호 저장 프로그램 
def runprogram():
	while True: #무한반복구문
		selnum=MenuSel()
		if selnum==1:
			InsertData()
		elif selnum==2:
			DisplayData(addresslist)
		elif selnum==3:
			DeleteData(addresslist)
		elif selnum==4:
			break #반복구문 탈출

def MenuSel():
	push=int(input('''Select Menu Please : 
		1 : Insert Data
		2 : Display Data
		3 : Delete Data
		4 : Good Bye

		'''))
	return push

def InsertData():
	Name=input("Name is : ")
	Number=input("Number is : ")
	if len(Number)<11:
		print("		Type again =_=")
	else:
		addresslist[Name]=Number

def DisplayData(addresslist):
	print()
	for x in addresslist:
		print(x,' : ',addresslist[x])
	print()

def DeleteData(addresslist):
	Killer=input("Which Name will you delete : ")
	if Killer not in addresslist:
		print("There`s no one who`s name is ",Killer," Try again")
	else:
		Hang=addresslist.pop(Killer)
		print(Killer," is Deleted")
		print("Remain Addresses : ")
		for x in addresslist:
			print(x,' : ',addresslist[x])
	print()


if __name__=="__main__":
	addresslist={}
	runprogram()