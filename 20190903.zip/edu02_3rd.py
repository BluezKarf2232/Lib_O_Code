#list에 항목넣기
print("Adding data")
print("1. Simple") #그냥 연산하기 
rawlist=[10,20,30]
print("ID of Raw List : ",id(rawlist))
id_before=int(id(rawlist))
rawlist+=[40,50]
print(rawlist)
print("ID of Raw List : ",id(rawlist))
id_after=int(id(rawlist))
if id_before == id_after:
	print("It`s ID has unchanged")
else:
	print("...Something`s Wrong")

print("2. append") #통째로 끼워넣기
rawlist=[10,20,30]
print("ID of Raw List : ",id(rawlist))
id_before=int(id(rawlist))
rawlist.append([40,50])
print(rawlist)
print("ID of Raw List : ",id(rawlist))
id_after=int(id(rawlist))
if id_before == id_after:
	print("It`s ID has unchanged")
else:
	print("...Something`s Wrong")

print("3. extend") #단순연산과 유사
rawlist=[10,20,30]
print("ID of Raw List : ",id(rawlist))
id_before=int(id(rawlist))
rawlist.extend([40,50])
print(rawlist)
print("ID of Raw List : ",id(rawlist))
id_after=int(id(rawlist))
if id_before == id_after:
	print("It`s ID has unchanged")
else:
	print("...Something`s Wrong")
#extend를 insert처럼 활용 못함...

print("4. insert") #위치를 지정해서 끼워넣는 append
rawlist=[10,20,30]
print("ID of Raw List : ",id(rawlist))
id_before=int(id(rawlist))
rawlist.insert(1,[40,50])
print(rawlist)
print("ID of Raw List : ",id(rawlist))
id_after=int(id(rawlist))
if id_before == id_after:
	print("It`s ID has unchanged")
else:
	print("...Something`s Wrong")

#공통적으로, 리스트에 객체를 더 끼워넣는다고 ID가 달라지진 않음.
print('''

	Deleting Data

	''')
prey=[10,20,30,40,50]
print(prey)
print("1. using del") #index 값 기준
del prey[0]
print(prey)
print("2. using remove") #데이터 기준
prey.remove(30)
print(prey)
print("3. using pop method") #index 위치 지정. 기본은 맨 끝(len(prey))
mit=prey.pop(1)
print(mit)
print(prey)
print("Advanced pop example")
prey=[10,20,30,40,50]
print("Before removal : ",prey)
print("I popped ",prey.pop(),',')
print("So ",prey,"Remains")
print("I popped ",prey.pop(1)," next,")
print("So ",prey," remains.")
print("Last, I popped ",prey.pop(0),",")
print(prey)

