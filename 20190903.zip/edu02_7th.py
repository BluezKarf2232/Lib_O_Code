#Tuple
tupledet=(2)
tupledata=(1,2,3,4)
print(type(tupledet))
print(type(tupledata))

data1=(2,4,8)
print(data1[1])
data2=(3,5,7)
print(data1+data2)
print(data2[0:2])
print(data2[::-1])
#data1[0]=5 #(에러남)
#del data2[0] #(에러남)

#Tuple 활용예제
def funk(tuple_dat):
	sum_data=0
	for x in tuple_dat:
		sum_data+=x
	avg=sum_data/len(tuple_dat)
	return sum_data,avg

mydata=(80,71,68,49,26,33)
ttl_avg=funk(mydata)
print(type(ttl_avg))
print(ttl_avg)
print()
#Tuple Format output
mylist=[123,456,78]
mytuple=("127.0.0.1",65432)
print("client {}가 접속".format(mytuple))
print("{} 전송 데이터".format(mylist))
print()
#Tuple 덧셈 연산
Tuple_dat=(2,4,6)
print(Tuple_dat)
print(id(Tuple_dat))
Tuple_dat=Tuple_dat+(8,)
#저 8 뒤에 , 안 붙이면, 저게 tuple 이 아닌 int로 인식이 되어 계산이 오류 남!
print(Tuple_dat)
print(id(Tuple_dat))

#Tuple 응용 예제
Names=("Lee","Kim","Park","Shin")
def low_out(dat):
	tmplist=[]
	for x in dat:
		tmplist.append(x.lower())
	return tuple(tmplist)

#print(type(Names))	# =tuple
LowTuple=low_out(Names)
#print(type(LowTuple))	# =tuple
sortNames=sorted(LowTuple)
#print(type(sortNames))	# =list ?!?!
print(tuple(sortNames))
print()
Buttonz=("1. Insert", "2. Display", "3. Delete", "4. Exit")
for x in Buttonz:
	print(x,' ',end="")
else:
	print("\n")
#일반적으로, Tuple은 변해선 안되는 데이터를 다룰 때 좋다.