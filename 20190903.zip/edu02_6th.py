#리스트 활용 예제
scorelist=[["Math"],["English"],["Korean"]]
'''
문제 : 수학, 영어, 국어 점수를 입력 한 뒤
총점 및 평균을 계산해서 출력하시오
'''
import sys
Math_score=int(input("Input Math score here : "))
if Math_score >100:
	print("You typed the wrong number")
	sys.exit()
if Math_score <0:
	print("You typed the wrong number")
	sys.exit()
else:
	pass
English_score=int(input("Input English score here : "))
if English_score >100:
	print("You typed the wrong number")
	sys.exit()
if English_score <0:
	print("You typed the wrong number")
	sys.exit()
else:
	pass
Korean_score=int(input("Input Korean score here : "))
if Korean_score >100:
	print("You typed the wrong number")
	sys.exit()
if Korean_score <0:
	print("You typed the wrong number")
	sys.exit()
else:
	pass
scorelist[0].append(Math_score)
scorelist[1].append(English_score)
scorelist[2].append(Korean_score)

total_score=0
for x in range(0,len(scorelist)):
	total_score+=scorelist[x][1]
print("Your test total score is ... ",total_score)
avg_score=total_score/3
print("Your test average score is ... {0:0.2f}".format(avg_score))

#예시 2(join, split 활용)
mylist=[3.23,4.56,2.8]
print("mylist is ",mylist)
mystr='/'.join([str(i) for i in mylist]) #list 내포 문법
print("mystr is ",mystr)
mylist=mystr.split('/')
print("mylist is ",mylist)
print("ID of mylist is ",id(mylist))
