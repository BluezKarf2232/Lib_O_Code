#class의 상속 : 모든 객체지향 프로그래밍에 있는 개념.
class Account(): #부모 코드
	def __init__(self,money):
		self.balance=money
	def deposit(self,money):
		self.balance+=money
	def withdraw(self,money):
		self.balance-=money
	def remains(self):
		print("You have {} Won".format(self.balance))

class fix1_Account(Account): #자식 코드 1. 부모인 Account의 내용물을 이어받음
	def deposit(self,money):
		self.balance+=money*1.07 #함수 재정의(오버라이딩)함
		print("Earn more.")
	def withdraw(self,money):
		self.balance-=money+10
		if self.balance<=0:
			print("You bankrupted!")
		else:
			print("Spend wisely.")

class fix2_Account(Account): #자식 코드 2
	def deposit(self,money):
		self.balance+=money*2.17
		print("Earn much more.")
	def withdraw(self,money):
		self.balance-=money+150
		if self.balance<=0:
			print("You bankrupted!")
		else:
			print("Spend wisely.")

class lazy_Account(Account): #자식코드 3 수정 안 하면 부모코드 '그대로' 씀
	print("Laaaaaaaaazy.") #클래스 내 메소드를 부르는 바람에 '아무 기능 안함'

print("Account(부모 클래스)출력")
act=Account(100)
act.remains()
act.deposit(100)
act.remains()
act.withdraw(50)
act.remains()
print("")
print("fix1_Account(자식 클래스 1번)출력")
actre=fix1_Account(100)
actre.remains()
actre.deposit(100)
actre.remains()
actre.withdraw(500)
actre.remains()
print("")
print("fix2_Account(자식 클래스 2번)출력")
actx=fix2_Account(100)
actx.remains()
actx.deposit(100)
actx.remains()
actx.withdraw(50)
actx.remains()
print("lazy_Account(자식 클래스 3번)출력")
actre=lazy_Account(100)
actre.remains()
actre.deposit(100)
actre.remains()
actre.withdraw(50)
actre.remains()
print("...")


#연산자 오버로딩
#myinst1.__sub__(myinst2)
print("Class interpret overloading")
class liscl():
	def __init__(self,data):
		self.mylist=data
	def showit(self):
		print(self.mylist)
	def __sub__(self,other): #객체 '-'기능 오버로딩을 '가능하게 함'
		mset1=set(self.mylist)
		mset2=set(other.mylist)
		otput=mset1-mset2
		return list(otput)

dedet1=[1,2,3,4,5]
dedet2=[5,7,8,2,4]
minst1=liscl(dedet1)
minst2=liscl(dedet2)
minst1.showit()
minst2.showit()

printit=minst1-minst2
print("minst1-minst2 : ",printit)
'''
이 아래 세 연산은 오버로딩을 허가하지 않아서 에러남!
hoxy1=minst1&minst2
hoxy2=minst1|minst2
hoxy3=minst1^minst2
print("Hoxy ... ",hoxy1,hoxy2,hoxy3)
'''
print("===============================")
#list 클래스 상속 + 연산자 오버로딩
class mlist(list):
	def __init__(self,name):
		self.name=name
		
	def __add__(self,other): #객체 '+'기능 오버로딩을 가능하게 함
			#조금 장난치자면, 아래 내용을 바꿔서 '+'의 기능을 바꿀 수 있다
		summit=[]
		summit.extend(self)
#장난 예시	:	summit.extend(["Is something`s Wrong?"])
		summit.extend(other)
		return summit
		

minst1=mlist("My 1st instant data : ")
for x in range(1,5):
	minst1.append(x)
print(minst1.name,minst1)

minst2=mlist("My 2nd instant data : ")
for x in range(5,10):
	minst2.append(x)
print(minst2.name,minst2)

result=minst1+minst2
print("Result is : ",result)