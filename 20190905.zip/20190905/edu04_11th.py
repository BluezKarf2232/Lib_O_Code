#Text Editer
import tkinter
from tkinter import filedialog

mywind = tkinter.Tk()
mywind.geometry("500x300")

text = tkinter.Text(mywind, width = 500, height = 300)
#Text editer 불러오기
text.pack()

mystr = None

def openfile():
	f = filedialog.askopenfile("rt")
	mystr_read = f.read()
	text.insert("1.0",mystr_read)
	#1행의 0번째 칸부터 읽어들인 파일 내용을 삽입

def savefile():
	global mystr
	mystr = text.get("1.0","end") #텍스트 파일 전체 읽기 
	print(type(mystr))
	if mystr == '\n':
		print("empty!!")
		return
	else:
		save_f = filedialog.asksaveasfile("wt")
		#읽어들인 내용이 있으면 새로운 파일 이름으로 파일 내용 저장
		save_f.write(mystr)
	save_f.close()

def EditClear():
	text.delete("1.0","end") #전체내용 삭제

def exit():
	mywind.quit()


menubar = tkinter.Menu(mywind)
mywind['menu'] = menubar

menu_file = tkinter.Menu(menubar, tearoff = 0)
menu_edit = tkinter.Menu(menubar, tearoff = 0)
menu_help = tkinter.Menu(menubar, tearoff = 0)

menubar.add_cascade(menu = menu_file, label = "File")
menubar.add_cascade(menu = menu_edit, label = "Edit") #메뉴 삽입
menubar.add_cascade(menu = menu_help, label = "Help")

menu_file.add_command(label = "open", command = openfile)
menu_file.add_command(label = "save as", command = savefile) #서브메뉴 삽입 및 커맨드 지정
menu_file.add_command(label = "Edit Clear", command = EditClear)
menu_file.add_command(label = "Exit", command = exit)

mywind.mainloop()
