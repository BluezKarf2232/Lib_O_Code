#Menubar
import tkinter
from tkinter import messagebox
from tkinter import filedialog

root=tkinter.Tk()
root.geometry("200x100")

f=None
filepath=tkinter.StringVar()
filepath.set("Show Filepath Here")

def openfile():
	global f
	f=filedialog.askopenfile("rb")
	filepath.set(f.name)

def saveasfile():
	global f
	a=f.read()
	if a is None:
		return
	else:
		save_f=filedialog.asksaveasfile("wb")
		filepath.set(save_f.name)
		save_f.write(a)
	f.close()
	save_f.close()

def exit():
	root.quit()

label_path=tkinter.Label(root,textvariable=filepath)
label_path.grid(row=0,column=0)


Menubar=tkinter.Menu(root)
root['menu']=Menubar

Menu_file=tkinter.Menu(Menubar,tearoff=0)
Menu_edit=tkinter.Menu(Menubar,tearoff=0)
Menu_help=tkinter.Menu(Menubar,tearoff=0)

Menubar.add_cascade(menu=Menu_file,label="File")
Menubar.add_cascade(menu=Menu_edit,label="Edit")
Menubar.add_cascade(menu=Menu_help,label="Help")

Menu_file.add_command(label='Open',command=openfile)
Menu_file.add_command(label='Save as...',command=saveasfile)
Menu_file.add_command(label='Exit',command=exit)

root.mainloop()