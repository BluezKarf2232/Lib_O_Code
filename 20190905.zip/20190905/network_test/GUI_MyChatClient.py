import tkinter
from tkinter import messagebox  #tkinter패기지 의  messagebox 모듈 등록
from socket import *
import threading

global Start
Start = True

class  MyChatMainCls:
	def __init__(self,Mainroot):
		self.Mainroot = Mainroot
		Mainroot.title("채팅창")
		Mainroot.geometry("420x600")
		self.MainChatFrame = tkinter.Frame(self.Mainroot)
		self.MainChatFrame.pack(fill="x")

		self.frame1 = tkinter.Frame(self.MainChatFrame)
		self.frame1.pack(fill="x")

		self.text = tkinter.Text(self.frame1)     # 수신 데이터 출력 Text
		self.text.pack(side = "right", fill="y")

        ## 수신 데이터 스크롤 기능 ##
		self.scroll1 = tkinter.Scrollbar(self.frame1)
		self.scroll1.pack(side = "right", fill="y")
		self.text.config(width=56, height = 38, state = "disabled", yscrollcommand = self.scroll1.set)

		self.text.pack(side = "left", fill= "both", expand = "yes")
		self.scroll1.config(command=self.text.yview)
		##############################################


		self.frame2 = tkinter.Frame(self.MainChatFrame)
		self.frame2.pack(fill="x")

		self.label1 = tkinter.Label(self.frame2, text = "본인 ID :")
		self.label1.pack(side = "left")

		self.entryname = tkinter.Entry(self.frame2, bd=1, width = 20)   # 본인 ID 송신 입력 Entry
		self.entryname.pack(side = "left")

		self.sendbutton = tkinter.Button(self.frame2, text = "ID 송신", width = 6, height = 1, command = self.sendmessage)
		self.sendbutton.pack(side = "left")



		self.frame3 = tkinter.Frame(self.MainChatFrame, padx=2, pady = 1)
		self.frame3.pack(fill="x")

		self.textentry = tkinter.Text(self.frame3, width = 48, height = 4)   # 메시지 송신 입력 Text
		self.textentry.pack(side = "left")
		self.sendbutton = tkinter.Button(self.frame3, text="메시지 송신", width = 12, height = 3, command = self.sendmessage)
		self.sendbutton.pack(side = "left")

		self.textentry.bind("<KeyRelease-Return>", self.MessageInput_Enter)  # textentry 에 데이터 입력후 엔터 키 입력시
																			 # 즉 엔터키 눌러다가 해제 될시 


	def textrefresh(self, message):
		self.text.config(state = "normal")
		self.text.insert("end", "\n" + message)

		self.text.config(state = "disabled")

	def MessageInput_Enter(self, event):
		self.sendmessage()

	def sendmessage(self):
		global Start
		if Start:
			message = self.entryname.get()
			Start = False
		else:
			message = self.textentry.get("1.0", "end")

		MyClientSock.send(bytes(message, "UTF-8"))
		self.textentry.delete("1.0", "end")


class ConnectInfo:
	def __init__(self, Connectroot):
		self.Connectroot = Connectroot
		Connectroot.title("서버 연결")
		Connectroot.geometry("500x400")
		self.ConnectmainFrame = tkinter.Frame(self.Connectroot)
		self.ConnectmainFrame.pack(fill="x")
		self.label1 = tkinter.Label(self.ConnectmainFrame, text = "서버 연결", font =("굴림체",20),width = 50, height = 3)
		self.label1.pack(side = "top")

		self.ConnectmainFrame1 = tkinter.Frame(self.Connectroot)
		self.ConnectmainFrame1.pack(fill="x")
		self.label1 = tkinter.Label(self.ConnectmainFrame1, text = "서버 IP 입력      : " ) # label
		self.label1.pack(side = "left")
		self.entry1 = tkinter.Entry(self.ConnectmainFrame1,bd =1, width = 20)   # Entry
		self.entry1.pack(side = "left")

		self.ConnectmainFrame2 = tkinter.Frame(self.Connectroot)
		self.ConnectmainFrame2.pack(fill="x")
		self.label2 = tkinter.Label(self.ConnectmainFrame2, text = "서버 Port 입력   : ")  # label
		self.label2.pack(side = "left")
		self.entry2 = tkinter.Entry(self.ConnectmainFrame2,bd = 1, width =20) # Entry
		self.entry2.pack(side = "left")


		self.ConnectmainFrame3 = tkinter.Frame(self.Connectroot)  # 공간 나누기 위한 임시 라벨 
		self.ConnectmainFrame3.pack(fill="x")
		self.label1 = tkinter.Label(self.ConnectmainFrame3, text = "", height = 2)
		self.label1.pack(side = "top")

		self.ConnectmainFrame4 = tkinter.Frame(self.Connectroot)
		self.ConnectmainFrame4.pack(fill="x")
		self.button = tkinter.Button(self.ConnectmainFrame4, text = "연결 요청", width = 3, height = 2, command= self.ConnectServer)
		self.button.pack(side = "top", fill = "x", padx = 200)


	def ConnectServer(self):
		global ip, port
		ip = self.entry1.get()

		port = int(self.entry2.get())

		self.Connectroot.quit()
		self.Connectroot.destroy()


def connect():
	print(ip)
	address =(ip, port)
	MyClientSock.connect(address)

	while True:
		data = MyClientSock.recv(1024)
		data = data.decode("UTF-8")
		if data:
			MyChatIns.textrefresh(data)


MyClientSock = socket(AF_INET, SOCK_STREAM)

mywin = tkinter.Tk()
ConnectIns = ConnectInfo(mywin)
mywin.mainloop()

mywin2 = tkinter.Tk()
MyChatIns = MyChatMainCls(mywin2)

#thread1 = threading.Thread(target=chatting)
thread2 = threading.Thread(target= connect)

#thread1.start()
thread2.start()

mywin2.mainloop()
