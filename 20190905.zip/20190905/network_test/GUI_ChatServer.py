import tkinter
from tkinter import messagebox  #tkinter패기지 의  messagebox 모듈 등록
from socket import *
import threading, sys

Server_Ip = "192.168.10.43"
Server_Port = 62567
address = (Server_Ip, Server_Port)

ServerSock = socket(AF_INET, SOCK_STREAM)
ServerSock.bind(address)
ServerSock.listen(2)
print("Waiting for connection..")

count = 0
connection = 0

def socket1():
	global client1, addr1, name1, count, connection
	count += 1
	client1, addr1 = ServerSock.accept()
	print("[알림] : " + str(addr1) + " 연결")
	connection += 1
	name1 = client1.recv(1024)
	name1 = name1.decode("UTF-8")
	sendmessage("[System]", name1 + "님이 입장하셧습니다.")
	while True:
		try:
			data1 = client1.recv(1024)
			data1 = data1.decode("UTF-8")
			sendmessage(name1, data1)
		except ConnectionError:
			print("ConnectionError")
			break
	count -= 1
	connection -= 1
	client1.close()

def socket2():	
	global client2, addr2, name2, count, connection
	count += 2
	client2, addr2 = ServerSock.accept()
	print("[알림] : " + str(addr2) + " 연결")
	connection += 2
	name2 = client2.recv(1024)
	name2 = name2.decode("UTF-8")
	sendmessage("[System]", name2 + "님이 입장하셧습니다.")
	while True:
		try:
			data2 = client2.recv(1024)
			data2 = data2.decode("UTF-8")
			sendmessage(name2, data2)
		except ConnectionError:
			print("ConnectionError")
			break
	count -= 2
	connection -= 2
	client2.close()


def sendmessage(name, data):
	message = name + " : " + data
	print(message)
	if connection == 1:
		client1.send(bytes(message,"UTF-8"))
	if connection == 2:
		client2.send(bytes(message,"UTF-8"))
	if connection == 3:
		client1.send(bytes(message,"UTF-8"))
		client2.send(bytes(message,"UTF-8"))

thread1 = threading.Thread(target= socket1)
thread2 = threading.Thread(target= socket2)
thread1.start()
thread2.start()

sys.exit()