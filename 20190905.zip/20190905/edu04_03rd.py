#파일 다루기
f=open("D:\\edu_python\\20190905\\file_test\\Testfile1.txt",'r')
#디렉토리 구분은 역슬래시 두 번!(\\)
for line in f:
	print(line.strip())
else:
	print('\n')
f.seek(0.0)
print(f.readlines())
f.close()
#파일 임의 접근
print("=================")
f=open("D:\\edu_python\\20190905\\file_test\\Testfile1.txt",'r+')
print(f.read())
print(f.tell())
f.seek(0.0)
f.write("C/C++")
f.flush()
f.seek(0.0)
print(f.read())
f.close