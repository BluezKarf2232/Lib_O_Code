'''
#5.Entry and messagebox
import tkinter
from tkinter import messagebox  #tkinter패기지 의  messagebox 모듈 등록

def CancelClick():
	text_id.set("")
	text_pw.set("")

def okClick():
	try:
		id_value = text_id.get()
		pw_value = text_pw.get()
   
		#messagebox.showinfo("입력데이터확인", "ID : {}, pw : {}".format(id_value, pw_value))
		messagebox.showinfo("입력데이터확인", "ID : %s, pw : %d"%(id_value, pw_value))
	except:
		messagebox.showwarning("입력오류", "정확히 입력 하세요")
		text_id.set("")
		text_pw.set("")

mywin = tkinter.Tk()
mywin.geometry("300x300")
frame = tkinter.Frame(mywin)
frame.pack()

text_id = tkinter.StringVar(value="")
text_pw = tkinter.IntVar(value = 0)

lb1 = tkinter.Label(frame, text = "ID(문자열 입력)")
lb1.grid(row = 0, column = 0)
txt = tkinter.Entry(frame, textvariable = text_id)
txt.grid(row = 0, column = 1)

lb2 = tkinter.Label(frame, text = "pw(정수입력)")
lb2.grid(row = 1, column = 0)
txt_pw = tkinter.Entry(frame, textvariable = text_pw, show="*")
txt_pw.grid(row = 1, column = 1)
text_pw.set("")

btn_ok  = tkinter.Button(frame, text = "입력 확인", command = okClick)
btn_ok.grid(row = 2, column = 1)

btn_cancel  = tkinter.Button(frame, text = "입력 취소", command = CancelClick)
btn_cancel.grid(row = 2, column = 2)
mywin.mainloop()
'''
'''
#6.Canvas
import tkinter
import random

def randxy():
	a = random.randint(1,250) #random int number
	return a

def click():
	cvs.create_line(randxy(), randxy(), randxy(), randxy())
	#(num1,num2,num3,num4) 라 할 때, (num1,num2) 점에서 (num3,num4) 까지의 직선을 긋는다

mywin = tkinter.Tk()
mywin.geometry("500x500")
cvs = tkinter.Canvas(mywin, width=250, height = 250)
#캔버스 범위를 설정. 따로 창 크기를 정해둔 경우, 캔버스 위치는 맨 위, 맨 가운데가 된다.
cvs.pack()

button = tkinter.Button(text = "click", command = click)
cvs.create_window(150,200, window = button)

label = tkinter.Label(text = "Hellow")
cvs.create_window(100,200, window=label)

mywin.mainloop()
'''


#7.Load Image
import tkinter
import time
mywin = tkinter.Tk()
mywin.geometry("700x500")
frame = tkinter.Frame(mywin)
frame.pack()
cvs = tkinter.Canvas(mywin, width=600, height = 400)
cvs.pack()
x = 100
y = 100
def movitt():
	for x in range(0,100):
		if x%25<=12:
			cvs.move(ball1, 10 ,5)
			mywin.update()
			time.sleep(0.1)
		elif x==99:
			break
		else:
			cvs.move(ball1, -10 ,-5)
			mywin.update()
			time.sleep(0.1)


img = tkinter.PhotoImage(file = "beachball.png")
ball1 = cvs.create_image(x,y, image = img)

btn_ok  = tkinter.Button(frame, text = "움직여!", command = movitt)
btn_ok.grid(row = 1, column = 0)


'''
for x in range(0,1000):
	cvs.move(ball1, 9 ,5)  
	mywin.update()
	time.sleep(0.05)
	'''
mywin.mainloop()
