#radio button
import tkinter

root=tkinter.Tk()
frame=tkinter.Frame(root)
frame.pack()

def result():
	var_result.set("I have checked "+var.get()+".")

var=tkinter.StringVar()
var.set("NOTHING")
var_result=tkinter.StringVar()
var_result.set('result')

r1=tkinter.Radiobutton(frame,text="SUN",variable=var,value="SUN",command=result)
r2=tkinter.Radiobutton(frame,text="MON",variable=var,value="MON",command=result)
r3=tkinter.Radiobutton(frame,text="TUE",variable=var,value="TUE",command=result)
r4=tkinter.Radiobutton(frame,text="WED",variable=var,value="WED",command=result)
r5=tkinter.Radiobutton(frame,text="THU",variable=var,value="THU",command=result)
r6=tkinter.Radiobutton(frame,text="FRI",variable=var,value="FRI",command=result)
r7=tkinter.Radiobutton(frame,text="SAT",variable=var,value="SAT",command=result)

label=tkinter.Label(frame,textvariable=var_result,background='green')
label.pack()

radiogroup=[r1,r2,r3,r4,r5,r6,r7]
for x in radiogroup:
	x.pack(side=tkinter.LEFT)
	#LEFT=왼쪽에서 오른쪽으로 정렬, RIGHT=오른쪽에서 왼쪽으로 정렬

root.mainloop()