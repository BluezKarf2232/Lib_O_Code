'''
#1. Grid
import tkinter
from tkinter import messagebox

def btn1clicked():
	messagebox.showinfo(title = "Btn1", detail = "btn1 clicked")

mywin = tkinter.Tk()
myframe = tkinter.Frame(mywin)
myframe.pack()
button1 = tkinter.Button(text="click1", padx = 25, pady = 10, command = btn1clicked)
button1.grid(in_=myframe, row = 0, column = 0, padx =25, pady=10)

button2 = tkinter.Button(myframe , text = "====button2====")
button2.grid(row = 1, column = 1)

button3 = tkinter.Button(myframe, text = "button3")
button3.grid(row = 2, column = 1, sticky = 'we')
mywin.mainloop()
'''
#2. Bind method
'''
import tkinter

def callback():
	mywin.title("Hello python")

mywin = tkinter.Tk()
mywin.geometry("{}x{}".format(500,300))
frame = tkinter.Frame(mywin, padx = 100, pady = 50)
frame.pack()

button = tkinter.Button(frame, text = "Button click")
button.pack()

label = tkinter.Label(frame, text = "Label click")
label.pack()
#1은 왼쪽버튼, 2는 가운데버튼, 3은 오른쪽버튼
#e = 이벤트정보
button.bind("<ButtonPress-1>", lambda e: callback())
button.bind("<Double-2>", lambda e: mywin.title("mouse Double click"))
button.bind("<ButtonPress-3>", lambda e: mywin.title("mouse Right click"))

label.bind("<Double-3>", lambda e: mywin.title("label event"))

mywin.mainloop()
'''
#3. [IMPORTANT] event element test
'''
import tkinter
from tkinter import messagebox

def test(e):
	a = """
char    : {}
delta   : {}
hight   : {}
keycode : {}
keysym  : {}
keysym_num : {}d
num     : {}
time    : {}
widget  : {}
width   : {}
x       : {}
y       : {}
x_root  : {}
y_root  : {}""".format(e.char,e.delta,e.height,e.keycode,e.keysym,e.keysym_num,e.num,e.time,e.widget,e.width,e.x,e.y,e.x_root,e.y_root)
	info.set(a)

def mouseclick(e):
    print("클릭위치", e.x, e.y)
    messagebox.showinfo(title = "mousexy", detail = "클릭 위치 {} {}".format(e.x, e.y))

mywin = tkinter.Tk()
info = tkinter.StringVar()

frame = tkinter.Frame(mywin, width = 500, height = 400, padx = 100, bg = "blue")
frame.grid()


button = tkinter.Button(mywin, text = "Test")
button.grid()

label_title = tkinter.Label(frame, text = "========= test Event=======", justify = "left")
label_title.grid()

label = tkinter.Label(frame, textvariable = info, justify = "left")
label.grid()
print(id(label))

frame.bind("<ButtonPress-1>", mouseclick)
mywin.bind("<MouseWheel>", lambda e : test(e))
mywin.bind("<KeyPress>", test)
mywin.bind("<Motion>", test)

mywin.mainloop()
'''

#4. 마우스 이벤트 처리 1(원 찍기)
'''
import tkinter
from tkinter import messagebox

def CallBack_Mouse(event):
	cvs.create_oval(event.x-10, event.y-10, event.x+10, event.y+10)

def Delete_pic(event):
	cvs.delete("all")

mywind = tkinter.Tk()

cvs = tkinter.Canvas(mywind, width = 500, height = 400)
cvs.pack()
#cvs.bind("<Button-1>", CallBack_Mouse)
cvs.bind("<B1-Motion>", CallBack_Mouse)
#마우스 왼쪽 버튼을 누른 상태에서 움직이기
cvs.bind("<Button-3>", Delete_pic)


mywind.mainloop()
'''
#5. 마우스 이벤트 처리 2(라인 그리기)
'''
import tkinter
from tkinter import messagebox
x0 = 0
y0 = 0

def Mouse_down(event):
	global x0, y0
	x0 , y0 = event.x, event.y

def Mouse_draw(event):
	global x0, y0
	cvs.create_line(x0,y0,event.x,event.y)
	x0, y0 = event.x, event.y

def Mouse_up(event):
	global x0, y0
	if (x0,y0) == (event.x, event.y):
		cvs.create_line(x0,y0, x0+1,y0+1)

def Delete_pic(event):
	cvs.delete("all")

mywind = tkinter.Tk()

cvs = tkinter.Canvas(mywind, width = 500, height = 400)
cvs.pack()
cvs.bind("<Button-1>", Mouse_down)
cvs.bind("<B1-Motion>", Mouse_draw)
cvs.bind("<ButtonRelease-1>", Mouse_up)
cvs.bind("<Button-3>", Delete_pic)


mywind.mainloop()
'''

#6. 마우스로 선 그리기 3+버튼으로 지우기

'''
import tkinter
from tkinter import messagebox

def mouseclick(e):
    print("클릭위치", e.x, e.y)
    global m_x, m_y
    m_x, m_y = e.x, e.y

def mousedraw(e):
	global m_x, m_y
	cvs.create_line(m_x, m_y, e.x, e.y)
	m_x , m_y = e.x, e.y

def mymouseup(e):
	global m_x, m_y
	if (m_x,m_y) == (e.x, e.y):
		cvs.create_line(m_x,m_y, m_x+1,m_y+1)

def delete_pic():
	cvs.delete("all")
mywin = tkinter.Tk()

cvs = tkinter.Canvas(mywin, width = 500, height = 400, bg = "blue")
cvs.grid()

button = tkinter.Button(mywin, text = "clear", command = delete_pic, foreground = "white", background = "black")
button.grid()

cvs.bind("<ButtonPress-1>", mouseclick)
cvs.bind("<ButtonRelease-1>", mymouseup)
cvs.bind("<B1-Motion>", mousedraw)

mywin.mainloop()
'''
