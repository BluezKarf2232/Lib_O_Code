#Checkbutton

'''import tkinter

root=tkinter.Tk()
frame=tkinter.Frame(root)
frame.pack()

check_a=tkinter.IntVar()
check_b=tkinter.StringVar()
cb_a=tkinter.Checkbutton(frame,text='check test 1',variable=check_a,onvalue=1,offvalue=0)
cb_a.grid(row=0,column=0)
label_a=tkinter.Label(frame,textvariable=check_a)
label_a.grid(row=1,column=0)
cb_b=tkinter.Checkbutton(frame,text='check test 2',variable=check_b,onvalue='ON',offvalue='OFF')
cb_b.grid(row=0,column=1)
label_b=tkinter.Label(frame,textvariable=check_b)
label_b.grid(row=1,column=1)

root.mainloop()'''

#Checkbutton 2
import tkinter
from tkinter import messagebox

def btnresult():
	result = []
	print("check_A status : ", check_A.get())
	print("check_B status : ", check_B.get())
	print("check_C status : ", check_C.get())
	if check_A.get() == "on":
		result.append("AI 기술")
	if check_B.get() == "on":
		result.append("자율 주행")
	if check_C.get() == "on":
		result.append("5G 통신")
	if check_D.get() == "on":
		result.append("친환경 기술")
	if check_A.get() != "on" and check_B.get() != "on" and check_C.get() != "on" and check_D.get() != "on":
		result.append("...없어?")

	selstr = " / ".join(result)
	messagebox.showinfo(title = "select tech", detail = selstr)

mywind = tkinter.Tk()
mywind.geometry("300x300")
frame = tkinter.Frame(mywind)
frame.pack()

check_A = tkinter.StringVar()
check_B = tkinter.StringVar()
check_C = tkinter.StringVar()
check_D = tkinter.StringVar()

check_A.set("off")
check_B.set("off")
check_C.set("off")
check_D.set("off")

label_tile = tkinter.Label(frame, text = "관심 기술 분야")
label_tile.grid(row=0, column = 0)

cb_A = tkinter.Checkbutton(frame, text = "AI 기술", variable = check_A, onvalue="on", offvalue="off")
cb_A.grid(row=1, column = 0)

cb_B = tkinter.Checkbutton(frame, text = "자율 주행", variable = check_B, onvalue="on", offvalue = "off")
cb_B.grid(row=1, column = 1)

cb_c = tkinter.Checkbutton(frame, text = "5G 통신", variable = check_C, onvalue="on", offvalue = "off")
cb_c.grid(row=2, column = 0)

cb_d = tkinter.Checkbutton(frame, text = "친환경 기술", variable = check_D, onvalue="on", offvalue = "off")
cb_d.grid(row=2, column = 1)

label = tkinter.Label(frame)
label.grid(row=3,column = 0)

buttonTest = tkinter.Button(frame, text = "result", command = btnresult)
buttonTest.grid(sticky = 'we') #west

mywind.mainloop()

