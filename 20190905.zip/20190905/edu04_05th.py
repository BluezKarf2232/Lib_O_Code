#tkinter 다루기
import tkinter

'''
[1. 기본 : 버튼 만들기]
Crate=tkinter.Tk() #창 새로 만들기
Crate.geometry("250x300") #창 크기 지정
bt=tkinter.Button(Crate,text="Baaam") #버튼 만들기
bt.grid(row=0,column=2)#버튼 위치 지정
lb_tst=tkinter.Label(Crate,text="It is Label")#라벨 만들기
lb_tst.grid(row=0,column=1)#라벨 위치 지정
'''

'''
[2. 버튼과 함수]
def change_bg():
	btn.configure(background="purple")

frame_up = tkinter.Frame(Crate, height = 60, width = 90, background = "blue")
frame_down = tkinter.Frame(Crate, height = 30, width = 90, background = "red")
frame_up.pack()
frame_down.pack()

btn = tkinter.Button(frame_down, text = "click", command = change_bg, 
	foreground = "white", background = "black",
	activeforeground = "blue",
	activebackground = "#FF007F")
btn.pack()
'''

'''
[3. 제어변수 설정]
def increase():
	number.set(number.get()+1)

Crate = tkinter.Tk()
Crate.geometry("200x200")
frame = tkinter.Frame(Crate)
frame.pack()

number = tkinter.IntVar(value = 0)
button = tkinter.Button(frame, text = "increase", command = increase)
button.pack()
label = tkinter.Label(frame, text = "start", textvariable = number)
label.pack()

'''

'''
[4. Entry]

def reset():
	id_text.set('')
	pw_text.set('')

Crate=tkinter.Tk()
Crate.title('Log in') #창 제목
Crate.geometry('200x200')
id_text=tkinter.StringVar(value='')
pw_text=tkinter.StringVar(value='')
frame=tkinter.Frame(Crate)
frame.pack()
btn=tkinter.Button(frame,text='reset',command=reset)
btn.grid(row=0,column=0,columnspan=2)
lbl=tkinter.Label(frame,text="ID")
lbl.grid(row=1,column=0)
id_entry=tkinter.Entry(frame,textvariable=id_text)
id_entry.grid(row=1,column=1)
lbl=tkinter.Label(frame,text='PW')
lbl.grid(row=2,column=0)
pw_entry=tkinter.Entry(frame,textvariable=pw_text, show='*')
pw_entry.grid(row=2,column=1)

'''

Crate.mainloop()#생성 + 실시간 갱신
