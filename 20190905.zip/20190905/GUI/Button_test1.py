import tkinter
mywin = tkinter.Tk()
mywin.geometry("200x200")
bt = tkinter.Button(mywin, text = "Quit")
bt.grid(row = 0, column = 2)
lb_test = tkinter.Label(mywin, text="label Create")
lb_test.grid(row = 0, column = 1)

mywin.mainloop()
