'''
#1: write(or create)
f=open("Testing.txt",'w')
f.write("Seals!")
f.close()
#2: read
f=open("Testing.txt",'r')
print(f.read())
f.close()
#3 append
f=open("Testing.txt",'a')
f.write("""
are
Cute!""")
f.close()
'''
