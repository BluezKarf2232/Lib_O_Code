import sys
f=open("D:\\edu_python\\20190905\\file_test\\mytext.txt",'r')
oriwords=f.read()
orilist=oriwords.split(" ") #공백을 기준으로 문자열을 구분, list로 만듦
print(orilist)
lis_dict={}
for x in orilist:
	tep=x.strip()
	if tep in lis_dict:
		lis_dict[tep]+=1
	else:
		lis_dict[tep]=1
print(len(lis_dict))
print(lis_dict)
