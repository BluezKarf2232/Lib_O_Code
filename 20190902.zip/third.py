string_object = "python programming"

total=[]#List 객체
for x in string_object:
	if x ==" ":
		total.append(" ")#빈 칸은 빈칸대로!
	else:
		total.append(chr(ord(x)-32))
'''
chr : 안의 숫자를 해당 아스키 코드의 문자로 바꿈
ord : 안의 문자를 해당 아스키 코드의 숫자로 바꿈
'''
print(total)#결과는 P,Y,T,H,...로 대문자 한 글자씩 분리된 상태.
string_big = "".join(total)#list 내용물을 한 번에 합쳐버림. 저 ""안에 다른 걸 넣으면 내용이 살짝 바뀐다. 시간 있을 때 Try it!

print("for statement used :")
print(string_big) #결과는, 모든 글자를 합쳐 문장을 만든 것. PYTHON PROGRAMMING 이라 출력했다면 성공!
print("=======================")
print("upper method used:")
string_up = string_object.upper() #...내장 문자열 객체 메소드. 결과는 위와 같음!
print(string_up)