fdata=3.421356
fdata2=5.345679
print("{0:0}".format(fdata))
print("{0:0.4f}".format(fdata))
print("{0:10.4f} or{1:10.3f}".format(fdata,fdata2))
#{(포멧을 집어올 데이터 번지):(실수 자리수).(소수점 이하 자리수)f}