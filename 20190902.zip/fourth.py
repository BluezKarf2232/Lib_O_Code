a="programming"
print(type(a)) #class = string
a=[1,2,3,4]
print(type(a)) #class = list
a=(5,6,7)
print(type(a)) #class = tuple
a={2,4,6,8}
print(type(a)) #class = set
a={"a":1, "b":2, "c":3}
print(type(a)) #class = dict

x = 5000.496
y = 5000.496
print(id(x))
print(id(y))
print(x is y) #두 객체의 ID값을 비교
print(x == y) #두 객체의 숫자값을 비교

print("==========================")

print(bool("false")) #=True ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ
print(10/3)
print(10//3)
print(10%3)
print(divmod(10,3))
print(10**3.1)
a=1
b=2.0
c=a+b
print(c)
print(type(c)) #서로 다른 수치 자료형 연산시 상위 자료형을 따름

print(2**3)

x=77.0
x//=7 #x=x//7과 동일한 연산(x//7을 한 뒤 x에 다시 대입함)
print(x)
print("==========================")
print(10==100)
print(10!=100)
print(1^1)