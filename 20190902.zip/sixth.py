print("When the number is between -5 and 256")
def func1(): #Define the function
	c=156
	print(id(c))

d=156
print(id(d))
func1() #Call the function
#-5에서 256까지 정수는 미리 객체를 생성해 두고, ID를 만들어 둔다. 
#그래서, 이 범위 내 같은 정수를 쓰는 변수는 ID도 같다.
print()
print("When the number is out from between -5 and 256")
def func2():
	c=257
	print(id(c))

d=257
print(id(d))
func2()
#-5~256을 벗어나는 정수 객체는 필요할 때 생성하므로, 같은 정수를 쓰더라도 
#ID가 다를 수 있다.
print(type(range(-30,260)))
print()
total=[]
for x in range(-5,30):
	total.append(x)
print(total)
print(type(total))

print(total[1])
total[1]="자라나라 머리머리"
print(total)