a = 1
b = 3.4
print(a)
print("type a :", type(a))
print("Id of a :", id(a))
print(b)
print("Type of b :", type(b))
print("Id of b :", id(b))
a = "Test"
print(a)
print("Type of a :", type(a))
print("Id of a :", id(a))
