print("First Python Programming")#print("Run Away!")
a = 1
b = 2
x = a+b
print(x)
'''
print("This is Hell!")
'''
print(type(x))
c = 3.4
print(type(c))

if True:
	print("True")
	print("So True")
else:
	print("False")
	print("rly False")
print("Prin`it Anyway")