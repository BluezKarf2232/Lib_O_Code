def mystr_func1():	#함수 정의
	mystr="Hello Python Programming"
	print(mystr)
	print('Pro' in mystr)

	count = 0
	for s in mystr:
		if s == 'P':
			count+=1
	print("P char count : %d" %count)
	#%count의 숫자값을 %d에 넣음
	#print("P char count :",count)
	#...귀찮으면 위의 걸로 대신해도 되고.

def mystr_func2():	#함수 정의
	mystr="Hello Python Programming"
	#print(mystr)
	#print('Pro' in mystr)

	count = 0
	for s in mystr:
		if s == 'g':
			count+=1
	return count

#mystr_func1() #함수 호출
res=mystr_func2() #return으로 받은 count값을 res값으로 지정 
print("res :",res) #그 res값을 출력!

ID_1="apPLe"
ID_2="BanAna"
print(ID_1<ID_2)
#print(ID_1.lower())
#print(ID_1.upper())
#print(ID_2.lower())
#print(ID_2.upper())
print(ID_1.lower()<ID_2.lower())
print(ID_1.upper()<ID_2.upper())
