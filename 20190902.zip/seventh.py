#lecture for String
str1='python' #문자 정의는 작은따음표로 
print(str1)
str2="I`m python" #큰 따음표로 해도 된다.
print(str2)
str3='"This is good"' #작은따음표를 쓰면 그 안에 큰따음표를 넣을 수 있다
print(str3)
str4="""Python
is
Great"""#여러줄에 걸쳐 쓸 땐 큰따음표 세 개 
print(str4)

str5="programming"
print(str5[0]) #색인연산 = str5의 0번째 '글자'를 읽어라
print(str5[3])
str_len=len(str5)
print(str_len)
print()
for idx in str5:
	print(idx, end=" ")
print()
for x in range(0,str_len):
	print(str5[x]," ",x)

a=0
while a < 5:
	print("Pass!")
	a=a+1
else:
	print("Stop!")