str1='good'
str2='python programming'
str3=str1+" "+str2 
'''
본래 사칙연산은 숫자의 특권. BUT 파이썬의 연산자 오버로딩 덕분에 이런 게 가능
'''
print(str3)
print()
stm="Python string!! "
print(stm*3)
print("X_X "*10)

sti="String index"
for x in range(0,len(sti)):
	print(sti[x]," ",x)
print()
print(sti[0],sti[2],sti[len(sti)-1])
'''
len(sti)는 12이지만, 마지막 글자에 부여된 숫자는 11이다.
즉, sti[12] 쓰면 에러남.
'''
print(sti[-1]) #문자의 맨 끝
print(sti[:-1]) #문자의 맨 끝 까지. 맨 끝의 x 빼고 다 나온다.
print(sti[::-1]) #!로꾸거
print(sti[::1]) #전부 순방향 출력
print(sti[1:8]) #분할연산=sti[1]부터 sti[8]까지 추출, 출력한다!
print(sti[::2]) #2스텝씩 = 처음 글자부터, 1문자식 건너뛰어 출력

mystr="python"
for x, c in enumerate(mystr): #문자에 index를 붙여 반환!
	print(x,c)
	print(mystr[x])
#정리하자면, sti[시작 넘버:끝 넘버:카운트 계수]