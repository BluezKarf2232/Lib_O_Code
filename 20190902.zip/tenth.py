#서식화된 출력
print("%s is %d year-old" %("Hong", 50))
print("Your height is %lf cm" %179.9)
#format()함수 활용
mystr="Name : {}, Age : {}".format("Hong",30)
print(mystr)
#시계열 활용
import time
tnow=time.localtime()
print(tnow)
print("현재시각은 {year}년 {mon}월 {mday}일 {hour}시 {min}분 입니다.".format(year=tnow.tm_year,mon=tnow.tm_mon,mday=tnow.tm_mday,hour=tnow.tm_hour,min=tnow.tm_min))