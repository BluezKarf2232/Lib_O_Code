print(1100 << 2)
'''
1100을 2진수로 변환 
->비트를 왼쪽으로 2칸 밂 
->그 수를 10진수로 재변환 
->1100의 4배, 즉 4400이 됨...
'''
print(~1)
print("and 연산")
a=10 and 20
print(a)
a=20 and 10
print(a)
a=0 and 20
print(a)
a=0 and 120
print(a) #좌항이 참일 땐 우항 값을 출력, 거짓일 땐 0을 출력
print("or 연산")
a=10 or 20
print(a)
a=20 or 10
print(a)
a=0 or 20
print(a)
a=0 or 120
print(a) #좌항이 참일 땐 좌항 값을 출력, 거짓일 땐 우항을 출력
print("============")
for x in range(1,10):
	res=x>5 and 10 or 20
	print(x,res)
print("============")
for x in range(1,10):
	print(x,end=" ") # 저 end가 없을 땐 기본 end는 \n (줄바꿈)임
x,y=3,6
print() #=print("\n")
print("x is ",x)
print("y is ", y)
print("Changing each other")
y,x=x,y #C언어에서는 불가
print("x is ", x)
print("y is ", y)
